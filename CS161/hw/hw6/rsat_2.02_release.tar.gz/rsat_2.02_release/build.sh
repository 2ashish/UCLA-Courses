#!/bin/sh
./build_satelite.sh
echo ============================
echo " Done building preprocessor "
echo ============================
make rsat
echo ============================
echo "     Done building RSat     "
echo ============================
