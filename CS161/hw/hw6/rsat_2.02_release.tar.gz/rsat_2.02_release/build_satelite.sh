cd SatEliteCode
./clean.sh
./build.sh
cd ..